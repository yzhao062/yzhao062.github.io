This is a personal repository for storing my CV with better traceability and 
easy access for sharing it (especially important for getting a permanent link
to eliminate the hassle of updating my homepage).